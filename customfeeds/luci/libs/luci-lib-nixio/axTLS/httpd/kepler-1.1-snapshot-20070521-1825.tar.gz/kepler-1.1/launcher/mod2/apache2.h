int luaopen_apache2 (lua_State *L);
/*void ap2_set_request_rec (lua_State *L, request_rec *r);*/
