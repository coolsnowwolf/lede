/* $Id: lfcgi.h,v 1.1 2005/03/02 21:10:04 tomas Exp $ */
LUALIB_API int luaopen_lfcgi (lua_State *L);
