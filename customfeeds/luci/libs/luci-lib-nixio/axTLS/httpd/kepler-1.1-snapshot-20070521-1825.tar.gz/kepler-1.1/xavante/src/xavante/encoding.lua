-----------------------------------------------------------------------------
-- Xavante Content-Encondings
--
-- Authors: Javier Guerra and Andre Carregal
-- Copyright (c) 2004-2007 Kepler Project
--
-- $Id: encoding.lua,v 1.2 2007/01/12 17:50:03 carregal Exp $
-----------------------------------------------------------------------------

xavante.encodings = {
  svgz = "x-gzip",
}