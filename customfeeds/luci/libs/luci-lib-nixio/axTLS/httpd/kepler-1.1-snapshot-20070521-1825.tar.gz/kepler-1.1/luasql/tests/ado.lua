#!/usr/local/bin/lua50

QUERYING_STRING_TYPE_NAME = "adLongVarWChar"
